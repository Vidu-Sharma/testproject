<h1>Forget Password Email</h1>
You can reset password from bellow link:
<a href="http://vidu.nascenture.com/reset?token={{$token}}">Reset Password</a>

